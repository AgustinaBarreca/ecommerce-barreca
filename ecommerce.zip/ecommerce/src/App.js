import "./App.css";
import NavBar from './components/global/NavBar.jsx';

function App() {
  return (
      <NavBar />
  );
}

export default App;

